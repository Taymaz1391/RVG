#!/bin/bash
echo "========================================================"
echo "       TOM AI - Android ADB Installer (Mac/Linux)"
echo "========================================================"
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
adb devices
echo "Installing TOM-AI-v4.5.apk..."
adb install -r "$DIR/TOM-AI-v4.5.apk"
