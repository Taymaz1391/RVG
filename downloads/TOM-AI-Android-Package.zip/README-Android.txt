============================================================
              TOM AI - Android Installation Guide
============================================================

[ENGLISH]
Option 1: Direct APK Installation (Recommended)
1. Transfer "TOM-AI-v4.5.apk" to your phone or download directly.
2. Tap the file in your Downloads or File Manager.
3. If prompted, enable "Allow installation from unknown sources".
4. Tap "Install" and open TOM AI!

Option 2: 1-Click ADB Install (via PC USB)
1. Connect your Android phone to PC via USB cable.
2. Enable "USB Debugging" in Developer Options.
3. Run "Install-with-ADB.bat" (Windows) or "install-with-adb.sh" (Mac/Linux).

Option 3: Instant Web App (PWA)
1. Open https://Taymaz1391.github.io/RVG/ in Google Chrome on Android.
2. Tap the three dots menu (⋮) -> "Add to Home screen" or "Install App".
3. TOM AI will install as a native standalone app!

------------------------------------------------------------
[راهنمای فارسی]
روش ۱: نصب مستقیم فایل نصبی APK (توصیه شده)
۱. فایل "TOM-AI-v4.5.apk" را روی گوشی انتقال دهید یا مستقیماً دانلود کنید.
۲. روی فایل در پوشه دانلودها یا مدیریت فایل کلیک کنید.
۳. در صورت نمایش پیام امنیتی، گزینه "مجاز کردن نصب از منابع ناشناخته" را فعال کنید.
۴. دکمه "نصب (Install)" را بزنید و برنامه تام را اجرا کنید!

روش ۲: نصب سریع از طریق کابل با ADB
۱. گوشی اندروید خود را با کابل USB به رایانه متصل کنید.
۲. گزینه اشکال‌زدایی USB (USB Debugging) را در تنظیمات توسعه‌دهنده گوشی فعال کنید.
۳. فایل "Install-with-ADB.bat" را اجرا کنید تا برنامه خودکار نصب شود.

روش ۳: نصب وب‌اپلیکیشن پیشرفته (PWA)
۱. آدرس https://Taymaz1391.github.io/RVG/ را در مرورگر کروم باز کنید.
۲. منوی سه‌نقطه (⋮) را باز کرده و گزینه "افزودن به صفحه اصلی" یا "نصب برنامه" را لمس کنید.
============================================================
