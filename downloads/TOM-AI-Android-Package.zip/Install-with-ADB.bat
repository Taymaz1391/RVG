@echo off
title TOM AI - Android ADB Installer
color 0A
echo ========================================================
echo        TOM AI - 1-Click Android ADB Installer
echo ========================================================
echo.
echo Checking ADB connection...
adb devices
echo.
echo Installing TOM-AI-v4.5.apk to your connected Android device...
adb install -r "%~dp0TOM-AI-v4.5.apk"
if %errorlevel% neq 0 (
    echo.
    echo [!] ADB install failed. Make sure:
    echo     1. USB Debugging is ENABLED on your Android phone.
    echo     2. Device is connected and authorized.
    echo.
) else (
    echo.
    echo [OK] TOM AI installed successfully on your Android phone!
)
pause
