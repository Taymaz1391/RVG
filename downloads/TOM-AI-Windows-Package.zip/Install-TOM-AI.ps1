# TOM AI - Advanced PowerShell Installer
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "       TOM AI - Autonomous Intelligence Suite" -ForegroundColor Green
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host ""

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$exePath = Join-Path $scriptDir "TOM-AI-Setup.exe"
$iconPath = Join-Path $scriptDir "assets\favicon.ico"
$desktop = [Environment]::GetFolderPath("Desktop")
$programs = [Environment]::GetFolderPath("Programs")

Write-Host "[1/3] Creating Desktop Shortcut..." -ForegroundColor Yellow
$ws = New-Object -ComObject WScript.Shell
$scDesktop = $ws.CreateShortcut((Join-Path $desktop "TOM AI.lnk"))
$scDesktop.TargetPath = $exePath
$scDesktop.IconLocation = $iconPath
$scDesktop.Description = "TOM AI - Autonomous Frontier Intelligence"
$scDesktop.Save()

Write-Host "[2/3] Creating Start Menu Entry..." -ForegroundColor Yellow
$scMenu = $ws.CreateShortcut((Join-Path $programs "TOM AI.lnk"))
$scMenu.TargetPath = $exePath
$scMenu.IconLocation = $iconPath
$scMenu.Description = "TOM AI - Autonomous Frontier Intelligence"
$scMenu.Save()

Write-Host "[3/3] Installation Complete! Launching TOM AI..." -ForegroundColor Green
Start-Process $exePath
