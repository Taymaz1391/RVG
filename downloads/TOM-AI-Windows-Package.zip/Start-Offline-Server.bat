@echo off
title TOM AI - Local Offline Web Server
color 0B
echo ========================================================
echo        TOM AI - 100% Offline Local Server
echo ========================================================
echo.
echo Zero internet required! Starting local micro-server...
echo.

set DIR=%~dp0app
cd /d "%DIR%"

start "" http://127.0.0.1:8000/index.html
python -m http.server 8000 2>nul || python3 -m http.server 8000 2>nul || py -m http.server 8000
pause
