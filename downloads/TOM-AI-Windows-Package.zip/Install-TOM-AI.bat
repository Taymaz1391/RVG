@echo off
title TOM AI - Windows Setup & Shortcut Creator
color 0A
echo ========================================================
echo        TOM AI - Autonomous Intelligence Setup
echo ========================================================
echo.
echo Installing TOM AI Desktop Shortcut and Start Menu entry...
echo.

set SCRIPT_DIR=%~dp0
set TARGET_EXE=%SCRIPT_DIR%TOM-AI-Setup.exe
set ICON_PATH=%SCRIPT_DIR%assets\favicon.ico

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws = New-Object -ComObject WScript.Shell; ^
   $s = $ws.CreateShortcut([System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'TOM AI.lnk')); ^
   $s.TargetPath = '%TARGET_EXE%'; ^
   $s.IconLocation = '%ICON_PATH%'; ^
   $s.Description = 'TOM AI - Autonomous Intelligence'; ^
   $s.Save(); ^
   $sm = [Environment]::GetFolderPath('Programs'); ^
   $s2 = $ws.CreateShortcut([System.IO.Path]::Combine($sm, 'TOM AI.lnk')); ^
   $s2.TargetPath = '%TARGET_EXE%'; ^
   $s2.IconLocation = '%ICON_PATH%'; ^
   $s2.Save();"

echo.
echo [OK] Shortcuts created successfully on Desktop and Start Menu!
echo.
echo Starting TOM AI now...
start "" "%TARGET_EXE%"
pause
