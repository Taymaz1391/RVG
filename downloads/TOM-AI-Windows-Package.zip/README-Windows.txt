============================================================
              TOM AI - Windows Installation & Usage
============================================================

[ENGLISH]
Thank you for downloading TOM AI!
TOM is a 100% autonomous, zero-API artificial intelligence.

How to Run & Install:
1. Quick Launch:
   Double-click "TOM-AI-Setup.exe" to immediately launch TOM AI.

2. Full Installation:
   Right-click "Install-TOM-AI.bat" (or Install-TOM-AI.ps1) and run.
   This creates desktop and Start Menu shortcuts with icons.

3. Complete 100% Offline Mode:
   Run "Start-Offline-Server.bat". This starts a local server on port
   8000 so you can use TOM AI anywhere with zero internet connection!

------------------------------------------------------------
[راهنمای فارسی]
از دانلود هوش مصنوعی تام (TOM AI) متشکریم!
تام یک مدل هوش مصنوعی کاملاً مستقل، بدون نیاز به هیچ API خارجی است.

روش‌های اجرا و نصب:
۱. اجرای سریع:
   روی فایل "TOM-AI-Setup.exe" دو بار کلیک کنید تا تام اجرا شود.

۲. نصب کامل و ساخت میانبر:
   روی فایل "Install-TOM-AI.bat" کلیک کنید تا میانبر دسکتاپ و
   منوی استارت به همراه آیکون برنامه خودکار ساخته شود.

۳. کارکرد کاملاً آفلاین (بدون اینترنت):
   فایل "Start-Offline-Server.bat" را اجرا کنید تا بدون نیاز به
   اینترنت، هوش مصنوعی به‌صورت کاملاً محلی روی رایانه شما اجرا شود!
============================================================
